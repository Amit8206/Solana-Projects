declare module "buffer-layout" {
  const magic: any;
  export = magic;
}

declare module "jazzicon" {
  const magic: any;
  export = magic;
}
