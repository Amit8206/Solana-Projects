By David Choi

Solana sample app to show wallet connection, message send, and lamport send.

The video explaining this code is here https://youtu.be/wVPGJ_CZTAw
