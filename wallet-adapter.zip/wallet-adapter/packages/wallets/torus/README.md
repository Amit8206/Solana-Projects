# `@solana/wallet-adapter-torus`

<!-- @TODO -->

Coming soon.