'use strict';

import './Buffer';
