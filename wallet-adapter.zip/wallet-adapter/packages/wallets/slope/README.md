# `@solana/wallet-adapter-slope`

<!-- @TODO -->

Coming soon.
