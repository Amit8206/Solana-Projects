# `@solana/wallet-adapter-base`

<!-- @TODO -->

Coming soon.
