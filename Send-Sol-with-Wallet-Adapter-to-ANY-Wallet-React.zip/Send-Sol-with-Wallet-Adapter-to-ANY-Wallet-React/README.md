<a href="https://serpent.academy">by Serpent Academy</a>
<p>Send SOL with Wallet Adapter in a Menu to any solana wallet with React and Web Hooks</p>
<img src="/screenshot.png">